package game;

public interface Updates {
	/**
	 * Sets location of element back to the beginning
	 */
	void resetLocation();
}
