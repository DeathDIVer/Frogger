package game;

import java.awt.Graphics;

public class Car extends Polygon {
	Speed speed;

	public Car(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
		
		this.speed = new Speed(2);
	}
	
	public void paint(Graphics brush) {
		Point[] points = getPoints();
		
		int[] xPoints = new int[points.length];
		int[] yPoints = new int[points.length];
		
		for(int i = 0; i < points.length; i++) {
			xPoints[i] = (int) points[i].getX();
			yPoints[i] = (int) points[i].getY();
		}
		
		brush.fillPolygon(xPoints, yPoints, points.length);
	}
	
	/**
	 * Moves car in the y direction, resetting its location when it travels off the grid
	 */
	public void move() {
		position.x += speed.getSpeed();
		
		if(position.x > 500) {
			resetLocation.resetLocation();
		}
	}

	Updates resetLocation = new Updates() {
		@Override
		public void resetLocation() {
			position.x = 0;
		}
	};
	
	public class Speed {
		private int speed;
		
		public Speed(int speed) {
			this.speed = speed;
		}
		
		public int getSpeed() {
			return speed;
		}
	}
}
